---
title: about
date: 2020-03-29 20:37:36
type: "about"
layout: "about"
comments:
description:
top_img:
mathjax:
katex:
aside:
---
#自我简介
欢迎来到我的博客，我是 HCLonely ,
一个 js 萌新，一切 js 知识全靠自学，并不会特别高大上的代码。
学习 js 只是为了自己日常使用，代码很乱，大佬勿喷。
---
#更多介绍
昵称: HCLonely
性别: ♂
爱好: JavaScript, 动漫，游戏，小说
邮箱: h1606051253@gmail.com
爱玩的游戏: Ori and the Blind Forest…
喜欢的动漫: 太多了…
喜欢的电影：漫威系列
喜欢逛的网站: 哔哩哔哩 , 其乐社区 , GitHub
…

---
作者: HCLonely
链接: https://blog.hclonely.com/whoami/
来源: HCLonely Blog
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
