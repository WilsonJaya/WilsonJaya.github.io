---
title: Hexo博客出现Cannot GET/xxx错误
date: 2020-03-27 10:10:36
tags:
  - hexo
  - 错误修正
categories: 
  - Debug
keywords: 'hexo，Cannot GET'
description: 在Hexo博客中，出现Cannot GET/xxx错误
top_img: https://s1.ax1x.com/2020/03/30/Geftc6.jpg
comments:
cover: https://s1.ax1x.com/2020/04/02/GYJNhn.jpg
toc:
toc_number:
copyright:
mathjax:
katex:
hide:
---
# Hexo博客出现Cannot GET/xxx错误

在Hexo博客中，出现Cannot GET/xxx错误便意味着xxx文件未被找到。Cannot GET/xxx错误本质是hexo server返回的一个404错误。

因此，排查方式如下：

1.判断public目录下xxx文件是否存在。（我的错误是 Cannot GET /，因此在public目录下寻找index.html是否存在。）

2.如果说index.html不存在，那么执行`hexo c`，`hexo g`重新生成一次，回到步骤1。

3.步骤2执行完后index.html仍不存在，执行`npm audit fix`，查看是否少了什么组件，通过`npm install hexo-xxx-xxx` 安装即可。
- 我的hexo就是缺少了`hexo-generator-index组件`，因此执行下面的代码即可：
```
npm install hexo-generator-index
```
4.步骤3完成之后，执行`hexo c`，`hexo g`重新生成静态文件。

５.如果依旧解决不了你的问题，请私信我。
参考文章：https://www.cnblogs.com/Sroot/p/6305938.html
作者：WilsonJaya
链接：https://blog.f531.ga/2020/03/28/Cannot-GETxxx/
来源：Jaya's blog
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
