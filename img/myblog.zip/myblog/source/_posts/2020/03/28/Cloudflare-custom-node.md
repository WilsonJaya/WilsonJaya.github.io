---
title: Cloudflare自定义节点(指定IP)的方法
date: 2020-03-28 20:01:19
tags:
  - Cloudflare
  - CDN加速
categories:
  - 教程
keywords: "定义节点,Cloudflare"
description: 国内访问CF的节点比较慢，教你Cloudflare自定义节点
top_img: https://s1.ax1x.com/2020/04/02/GY0JW4.png
comments:
cover: https://s1.ax1x.com/2020/04/02/GY08FU.png
toc:
toc_number:
copyright:
mathjax:
katex:
hide:
---
# Cloudflare自定义节点(指定IP)的方法

一般需要自选IP的原因是因为国内访问CF的节点比较慢，因此我们指定一个在国内访问比较快的IP。<br />自选IP的原理简单来说就是，国内DNS解析域名的时候能够解析到一个相对较快的IP，而国外解析的IP不变。

因此需要做几个前置动作。

1. 接入CF合作伙伴
1. 修改nameserver到第三方
1. 指定线路解析
- CF合作伙伴接入<br />

这里以本站为例，使用的是[笨牛网](https://cdn.bnxb.com/)。也可以使用其他的CF合作伙伴接入。原理是一样的。<br />把网站接入改成cname接入，记得先备份一下解析记录，接入变更以后直接在笨牛网导入。

然后把你需要的二级域名添加上解析，选择A记录，回源地址为服务器的IP地址。<br />页面下方会有cname信息。

- 智能DNS服务商分线路解析<br />

这里本站使用的[阿里云解析](https://dns.console.aliyun.com/#/dns/domainList)，同时还有国内还有dnspod,dns.la,dns.com等很多服务商也提供智能线路解析，可以网上搜下。<br />以阿里云解析为例，添加域名，然后按照提示在你的域名注册商修改ns到阿里提供的ns服务器，<br />然后把刚刚备份的域名解析列表导入进去，或者手动添加也可以。<br />把你需要解析的二级域名用cname的方式解析到刚刚在CF合作伙伴生成的cname上。解析线路选择默认。<br /> 

 

- 分线路解析<br />

选择一个线路较好的IP，然后分运营商做好相对应的IP的A记录解析即可。<br />

- 网上搜集的节点<br />

 <br />CloudFlare的节点：国内速较快的IP段：
> 联通移动推荐的节点
> 电信推荐CloudFlare 百度云合作 ip
> 162.159.208.4-162.159.208.103
> 162.159.209.4-162.159.209.103
> 162.159.210.4-162.159.210.103
> 162.159.211.4-162.159.211.103

<a name="VyTEm"></a>
### 电信
推荐选择上面的百度云合作IP。
<a name="OIsQc"></a>
### 移动
新加坡<br />104.18.48.0-104.18.63.255<br />104.24.112.0-104.24.127.255<br />104.27.128.0-104.27.143.255<br />104.28.0.0-104.28.15.255<br />圣何塞 cogentco.com<br />104.28.16.0-31.255<br />104.27.144.0-243.254<br />104.23.240.0-243.254<br />香港cloudflare1-100g.hkix.net<br />大部分都是这个通道<br />1.0.0.0-254<br />1.1.1.0-254<br />66.235.200.0-254 此段为IPOWER.COM endurance.com专用，有可能被跳转到IPOWER.COM endurance.com页面<br />104.16.80.0-95.255<br />104.16.175.255-104.16.191.255<br />香港直连<br />23.227.63.0-254 此段为shopify.com专用，有可能被跳转到shopify.com页面<br />104.16.0.0-79.255<br />104.16.96.0-175.254<br />104.16.192.0-207.255<br />新加坡 ae-0.cloudflare.sngpsi07.sg.bb.gin.ntt.net<br />都从香港ntt转发<br />104.28.0.0-15.255
<a name="MGZEc"></a>
### 联通
一般情况下和电信的IP一样即可。<br />等待一段时间之后就可以查看解析生效了没有。

最后，注意如果使用的是国内的云解析服务商，记得去域名注册商把dnssec删掉，不然的话，因为国内的dns服务商都不支持dnssec，谷歌和cloudflare的dns会拒绝解析。<br />本站就是这个原因导致前后几天域名一直解析不到IP地址。检查dnssec可以去dnsviz.net

