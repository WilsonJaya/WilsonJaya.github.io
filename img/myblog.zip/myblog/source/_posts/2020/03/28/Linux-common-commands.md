---
title: Linux常用的一些命令（含解析）
date: 2020-03-28 20:43:27
tags:
  - Linux
  - 命令行
categories:
  - 教程
  - Linux
keywords: "常用命令"
description: 
top_img: https://s1.ax1x.com/2020/04/02/GYBFXR.jpg
comments:
cover: https://s1.ax1x.com/2020/04/02/GY01oT.png
toc:
toc_number:
copyright:
mathjax:
katex:
hide:
---
# Linux常用的一些命令（含解析）

Linux这么多命令，通常会让初学者望而生畏。下面是我结合日常工作，以及在公司的内部培训中，针对对Linux不是很熟悉的同学，精选的一批必须要搞懂的命令集合

任何一个命令其实都是可以深入的，比如`tail -f`和`tail -F`的区别。我们不去关心，只使用最常见的示例来说明。本文不会教你具体的用法，那是抢man命令的饭碗。这只是个引导篇，力求简洁。

学习方式：多敲多打，用条件反射替代大脑记忆–如果你将来或者现在要用它来吃饭的话。 其中，也有一些难啃的骨头，关注小姐姐味道微信公众号，我们一起用锋利的牙齿，来把它嚼碎。
内容：
- 目录操作
- 文本处理
- 压缩
- 日常运维
- 系统状态概览
- 工作常用

## 1. 目录操作
工作中，最常打交道的就是对目录和文件的操作。linux提供了相应的命令去操作他，并将这些命令抽象、缩写。

### 1.1 基本操作
可能是这些命令太常用了，多打一个字符都是罪过。所以它们都很短，不用阿拉伯数字，一个剪刀手就能数过来
![](https://ciweigg2.github.io/images/2020/01/05/fae72d40-2fb2-11ea-a9cb-bb9279b30331.png)
看命令
```bash
- mkdir 创建目录 make dir
- cp 拷贝文件 copy
- mv 移动文件 move
- rm 删除文件 remove
```
例子：
```bash
# 创建目录和父目录a,b,c,d
mkdir -p a/b/c/d

# 拷贝文件夹a到/tmp目录
cp -rvf a/ /tmp/

# 移动文件a到/tmp目录，并重命名为b
mv -vf a /tmp/b

# 删除tmp目录的所有文件
rm -rvf /tmp/
```
### 1.2 漫游
linux上是黑漆漆的命令行，依然要面临人生三问：我是谁？我在哪？我要去何方？
ls 命令能够看到当前目录的所有内容。ls -l能够看到更多信息，判断你是谁。
pwd 命令能够看到当前终端所在的目录。告诉你你在哪。
cd 假如你去错了地方，cd命令能够切换到对的目录。
find find命令通过筛选一些条件，能够找到已经被遗忘的文件。
至于要去何方，可能就是主宰者的意志了。
### 1.3 文本处理

这是是非常非常加分的技能。get到之后，也能节省更多时间来研究面向对象
![](https://ciweigg2.github.io/images/2020/01/05/13ae1a50-2fb3-11ea-a9cb-bb9279b30331.png)
#### 查看文件
##### cat
最常用的就是`cat`命令了，注意，如果文件很大的话，`cat`命令的输出结果会疯狂在终端上输出，可以多次按`ctrl+c`终止。
```bash
# 查看文件大小
du -h file

# 查看文件内容
cat file
```
##### less
既然cat有这个问题，针对比较大的文件，我们就可以使用less命令打开某个文件。 类似vim，less可以在输入/后进入查找模式，然后按n(N)向下(上)查找。
有许多操作，都和vim类似，你可以类比看下。
##### tail
大多数做服务端开发的同学，都了解这么命令。比如，查看nginx的滚动日志。
```bash
tail -f access.log
```
tail命令可以静态的查看某个文件的最后n行，与之对应的，head命令查看文件头n行。但head没有滚动功能，就像尾巴是往外长的，不会反着往里长。
```bash
tail -n100 access.log
head -n100 access.log
```
### 1.4 统计
sort和uniq经常配对使用。 sort可以使用-t指定分隔符，使用-k指定要排序的列。
下面这个命令输出nginx日志的ip和每个ip的pv，pv最高的前10
```bash
# 2019-06-26T10:01:57+08:00|nginx001.server.ops.pro.dc|100.116.222.80|10.31.150.232:41021|0.014|0.011|0.000|200|200|273|-|/visit|sign=91CD1988CE8B313B8A0454A4BBE930DF|-|-|http|POST|112.4.238.213

awk -F"|" '{print $3}' access.log | sort | uniq -c | sort -nk1 -r | head -n10
```
### 1.5 其他
#### grep
grep用来对内容进行过滤，带上–color参数，可以在支持的终端可以打印彩色，参数n则输出具体的行数，用来快速定位。
比如：查看nginx日志中的POST请求。
```bash
grep -rn --color POST access.log
```
推荐每次都使用这样的参数。

如果我想要看某个异常前后相关的内容，就可以使用ABC参数。它们是几个单词的缩写，经常被使用。 A after 内容后n行 B before 内容前n行 C count? 内容前后n行
就像是这样：

```bash
grep -rn --color Exception -A10 -B2   error.log
```
#### diff
diff命令用来比较两个文件是否的差异。当然，在ide中都提供了这个功能，diff只是命令行下的原始折衷。对了，diff和patch还是一些平台源码的打补丁方式，你要是不用，就pass吧。
## 2 压缩
为了减小传输文件的大小，一般都开启压缩。linux下常见的压缩文件有tar、bzip2、zip、rar等，7z这种用的相对较少。
.tar 使用tar命令压缩或解压
.bz2 使用bzip2命令操作
.gz 使用gzip命令操作
.zip 使用unzip命令解压
.rar 使用unrar命令解压
最常用的就是.tar.gz文件格式了。其实是经过了tar打包后，再使用gzip压缩。
### 2.1 创建压缩文件
```bash
tar cvfz  archive.tar.gz dir/
```
### 2.2 解压
```bash
tar xvfz. archive.tar.gz
```
快去弄清楚它们的关系吧。






















