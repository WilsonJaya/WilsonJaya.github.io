---
title: Windows使用RaiDrive挂载Google Drive/OneDrive/Dropbox/FTP为本地硬盘
date: 2020-03-29 19:43:27
tags: 
 - RaiDrive
 - OneDrive
 - Google Drive
categories: 
 - 教程
keywords: "raidrive,onedrive,挂载"
description: 使用RaiDrive挂载Google Drive/OneDrive/Dropbox/FTP为本地硬盘
top_img: https://s1.ax1x.com/2020/03/30/GefJ91.jpg
comments:
cover: https://s1.ax1x.com/2020/04/02/GY0KLq.png
toc:
toc_number:
copyright:
mathjax:
katex:
hide: #设为true即可隐藏文章
---
# Windows使用RaiDrive挂载Google Drive/OneDrive/Dropbox/FTP为本地硬盘

## 介绍

RaiDrive是一款免费使用在Windows平台下的网盘挂载工具，可以把自己的网盘或FTP直接挂载到本地使用，同时支持Google Drive共享硬盘（无限盘），支持的挂载内容众多，使用也非常方便，小巧的体积强大的功能；
![](/img/2020/03/29/RaiDrive/1.png)

## 支持

- Windows 7
- Windows 8 / 8.1
- Windows 10
- Windows Server 2008 R2
- Windows Server 2012
- Windows Server 2012 R2
- Windows Server 2016
- Windows Server 2019

## 下载

传送门：[官方下载](https://www.raidrive.com/download/)
传送门：本地下载(暂无)

## 预览

![](/img/2020/03/29/RaiDrive/2.png)

![](/img/2020/03/29/RaiDrive/3.png)

![](/img/2020/03/29/RaiDrive/4.png)

## 注意

国内挂载`Google Drive`和`Dropbox`需要开启全局代理
全局代理工具：

